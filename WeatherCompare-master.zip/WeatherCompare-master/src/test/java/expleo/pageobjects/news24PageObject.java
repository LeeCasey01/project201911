package expleo.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class news24PageObject {

    //Object Variables
    @FindBy(how = How.XPATH, using = "//*[@id='wrapper']/table/tbody/tr[3]/td/div[2]/div[1]/a[3]")
    private WebElement Durban;

    public void SelectDurban(){
        Durban.click();
    }
}

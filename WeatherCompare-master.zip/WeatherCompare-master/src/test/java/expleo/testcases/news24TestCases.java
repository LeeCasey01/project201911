package expleo.testcases;

import expleo.pageobjects.news24PageObject;
import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.*;

import java.util.concurrent.TimeUnit;

import static org.junit.Assert.fail;

public class news24TestCases {
    private WebDriver driver;
    private String baseUrl="";
    private StringBuffer verificationErrors = new StringBuffer();
    @Before
    public void setUp() throws Exception {
        driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }


    @Test
    public void testNewRegistration() throws Exception {

        WritableWorkbook wbOut = Workbook.createWorkbook(new File("/home/training/IdeaProjects//Results.xls"));
        WritableSheet s = wbOut.getSheet(("Sheet1"));

        //Create news24 page factory
        news24PageObject news24Page = PageFactory.initElements(driver, news24PageObject.class);

        //Navigate to news24 weather website
        driver.get("http://weather.news24.com/");

        //Select the link to navigate to the Durban page
        news24Page.SelectDurban();

        //Create two arraylists to store min and max temps
        List<Integer> min = new ArrayList<Integer>();
        List<Integer> max = new ArrayList<Integer>();

        for(int i = 3; i <= 6;i++) {
            //Xpath for saturday text //*[@id="div7DayForecast"]/div/div/div[3]/text()[2]
            String text = driver.findElement(By.xpath("//*[@id=\"div7DayForecast\"]/div/div/div[" + i + "]")).getText();

            //Get min and max temperature from what is returned from website
            String[] res = text.split("°C - ");
            String minTemp = (res[0].toString().replaceAll("[^0-9]", ""));
            String maxTemp = (res[1].toString().replaceAll("[^0-9]", ""));

            //Convert strings to ints
            int minTempInt = Integer.parseInt(minTemp);
            int maxTempInt = Integer.parseInt(maxTemp);

            //Add values to arraylists
            min.add(minTempInt);
            max.add(maxTempInt);
        }
        //Print out arraylists
        System.out.println(min);
        System.out.println(max);


    }

    @After
    public void tearDown() throws Exception {
        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }

    private boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }
}

